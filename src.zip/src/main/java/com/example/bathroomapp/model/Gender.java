package com.example.bathroomapp.model;

public enum Gender {
    M,
    F,
    N
}
