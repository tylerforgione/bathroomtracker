package com.example.bathroomapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BathroomApp {
    public static void main(String[] args) {
        SpringApplication.run(BathroomApp.class, args);
    }
}
