package com.example.bathroomapp.controller;

import com.example.bathroomapp.dto.RegisterUserRequest;
import com.example.bathroomapp.model.User;
import com.example.bathroomapp.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    // DTOs for requests
    public static class RegisterRequest {
        public String email;
        public String username;
        public String password;
    }

    public static class LoginRequest {
        public String usernameOrEmail;
        public String password;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterUserRequest request) {
        User user = new User(
                request.email,
                request.username,
                request.password
        );

        // don’t expose passHash
        user.setPasswordHash(null);
        return ResponseEntity.ok(user);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        return userService.authenticate(request.usernameOrEmail, request.password)
                .map(user -> {
                    // generate a JWT or session
                    return ResponseEntity.ok("Login successful for user: " + user.getUsername());
                })
                .orElseGet(() -> ResponseEntity.status(401).body("Invalid credentials"));
    }
}