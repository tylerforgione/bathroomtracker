package com.example.bathroomapp.controller;

public class UserController {
}
