package com.example.bathroomapp.service;

import com.example.bathroomapp.dto.RegisterUserRequest;
import com.example.bathroomapp.dto.UserResponseDTO;
import com.example.bathroomapp.model.User;
import com.example.bathroomapp.repo.UserRepo;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    private final UserRepo userRepo;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public UserService(UserRepo userRepo) {
        this.userRepo = userRepo;
    }
    // Register
    public UserResponseDTO register(RegisterUserRequest r) {
        if (userRepo.findByEmail(r.email).isPresent()) {
            throw new RuntimeException("Email already exists");
        }

        if (userRepo.findByUsername(r.username).isPresent()) {
            throw new RuntimeException("Username already in use");
        }

        String hash = passwordEncoder.encode(r.password);

        User user = new User(r.email, r.username, hash);
        userRepo.save(user);

        return toDTO(user);
    }

    // Login
    public Optional<User> authenticate(String usernameOrEmail, String rawPassword) {
        Optional<User> userOpt =
                userRepo.findByUsername(usernameOrEmail)
                        .or(() -> userRepo.findByEmail(usernameOrEmail));

        if (userOpt.isEmpty()) return Optional.empty();

        User user = userOpt.get();
        boolean matches = passwordEncoder.matches(rawPassword, user.getPasswordHash());

        return matches ? userOpt : Optional.empty();
    }

    private UserResponseDTO toDTO(User u) {
        UserResponseDTO udto = new UserResponseDTO();
        udto.id = u.getId();
        udto.email = u.getEmail();
        udto.username = u.getUsername();
        return udto;
    }
}