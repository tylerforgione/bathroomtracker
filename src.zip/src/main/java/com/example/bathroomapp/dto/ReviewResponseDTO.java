package com.example.bathroomapp.dto;

public class ReviewResponseDTO {
    public Long id;
    public int rating;
    public int cleanliness;
    public int smell;
    public String comment;
    public String username;
}
