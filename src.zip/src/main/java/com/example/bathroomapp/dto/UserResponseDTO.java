package com.example.bathroomapp.dto;

public class UserResponseDTO {
    public Long id;
    public String email;
    public String username;
}
