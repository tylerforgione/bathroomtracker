package com.example.bathroomapp.dto;

public class RegisterUserRequest {
    public String email;
    public String username;
    public String password;
}
