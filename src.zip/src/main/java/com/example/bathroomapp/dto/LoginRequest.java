package com.example.bathroomapp.dto;

public class LoginRequest {
    public String usernameOrEmail;
    public String password;
}
